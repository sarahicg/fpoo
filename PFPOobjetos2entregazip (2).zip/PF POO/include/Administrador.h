/*
 Proposito:La clase es el gestor de los usuarios del sistema ,aqui se almacena,guarda y controla
 el acceso a los usuarios registrados y por crear,permitiendo que la interaccion
  con las demas clases sea un pco mas organizada.
 Autores:  Michell Correa  - 2551211
           Sarahi Gomez    - 2551061-2724
            Christian Tapia - 2551312-2724
 Fecha : 05/05/2026
 Version:  1.0
 */
#pragma once
#include <vector>
#include <iostream>
#include "Usuario.h"
using namespace std;

class Administrador {
private:
    vector<Usuario> usuarios;

public:

    void agregarUsuario(const Usuario &u) {
        usuarios.push_back(u);
    }

    void listarUsuarios() {
        cout << "\n--- USUARIOS ---\n";
        for (auto &u : usuarios) {
            cout << "ID: " << u.getId()
                 << " | Nombre: " << u.getNombre()
                 << " | Rol: " << u.getRol() << endl;
        }
    }

    Usuario* buscarPorId(int id) {
        for (auto &u : usuarios) {
            if (u.getId() == id)
                return &u;
        }
        return nullptr;
    }

    Usuario* login(string nombre, string pass) {
        for (auto &u : usuarios) {
            if (u.login(nombre, pass))
                return &u;
        }
        return nullptr;
    }
};
