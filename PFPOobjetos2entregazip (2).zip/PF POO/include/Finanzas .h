/*
 Proposito: Este archivo gestiona el sistema fianciero del usuario incluyendo gastos clasificados por categoria
 (vivienda, alimentacion, transporte, servicios, otros) y obtiene un peque�o balance cuando se compara con los ingresos del usuario.
 Autores:  Michell Correa  - 2551211
           Sarahi Gomez    - 2551061-2724
            Christian Tapia - 2551312-2724
 Fecha : 05/05/2026
 Version:  1.0
 */
#pragma once
#include <iostream>
using namespace std;

class Finanzas {
private:
    float vivienda = 0, alimentacion = 0, transporte = 0, estudios = 0, ocio = 0;
    float ingresosTotal = 0;

public:

    void agregarIngreso() {
        float ing;
        cout << "Ingrese sus ingresos mensuales: ";
        cin >> ing;

        if (ing > 0)
            ingresosTotal += ing;
    }

    void agregarGasto() {
        float gast;
        int tipo;

        cout << "Ingrese monto del gasto: ";
        cin >> gast;

        cout << "1.Vivienda 2.Alimentacion 3.Transporte 4.Estudios 5.Ocio\n";
        cin >> tipo;

        switch (tipo) {
            case 1: vivienda += gast; break;
            case 2: alimentacion += gast; break;
            case 3: transporte += gast; break;
            case 4: estudios += gast; break;
            case 5: ocio += gast; break;
            default: cout << "Tipo no valido\n";
        }
    }

    void mostrar() {
        cout << "\n���ESTADO FINANCIERO ���\n";
        cout << "Ingresos: " << ingresosTotal << endl;
        cout << "Vivienda: " << vivienda << endl;
        cout << "Alimentacion: " << alimentacion << endl;
        cout << "Transporte: " << transporte << endl;
        cout << "Estudios: " << estudios << endl;
        cout << "Ocio: " << ocio << endl;
        cout << "Total gastos: " << getGastos() << endl;
        cout << "Balance: " << (ingresosTotal - getGastos()) << endl;
    }

    float getIngresos() {
        return ingresosTotal;
    }

    float getGastos() {
        return vivienda + alimentacion + transporte + estudios + ocio;
    }
};
