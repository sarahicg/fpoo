/*
 Proposito:controlar la ejecucion del programa,crea y gestiona  accesos mediante papeles
 especificos y segun esto dirigira  al usuario a un menu especifico segun sea su rol.

 Autores:  Michell Correa  - 2551211
           Sarahi Gomez    - 2551061-2724
            Christian Tapia - 2551312-2724
 Fecha : 05/05/2026
 Version:  1.0
 */
#pragma once
#include <iostream>
#include "Administrador.h"
using namespace std;

class Sistema {
private:
    Administrador admin;

public:

    void ejecutar() {
        int op;

        do {
            cout << "\n----LOGIN SISTEMA ----\n";
            cout << "1. Crear usuario\n";
            cout << "2. Login\n";
            cout << "3. Listar usuarios\n";
            cout << "4. Buscar por ID\n";
            cout << "0. Salir\n";
            cin >> op;

            switch (op) {
                case 1: crearUsuario(); break;
                case 2: login(); break;
                case 3: admin.listarUsuarios(); break;
                case 4: buscar(); break;
            }

        } while (op != 0);
    }

private:

    void crearUsuario() {
        int id;
        string nombre, pass, rol;

        cout << "ID: "; cin >> id;
        cout << "Nombre: "; cin >> nombre;
        cout << "Password: "; cin >> pass;

        cout << "Rol (admin / estudiante / invitado): ";
        cin >> rol;

        Usuario u(id, nombre, pass, rol);
        admin.agregarUsuario(u);
    }

    void login() {
        string nombre, pass;

        cout << "Nombre: ";
        cin >> nombre;
        cout << "Password: ";
        cin >> pass;

        Usuario* u = admin.login(nombre, pass);

        if (u == nullptr) {
            cout << "Credenciales incorrectas\n";
            return;
        }

        cout << "\nLogin exitoso\n";

        string rol = u->getRol();


        if (rol == "admin") {
            menuAdmin(u);
        }
        else if (rol == "estudiante") {
            menuEstudiante(u);
        }
        else {
            menuInvitado(u);
        }
    }


    void menuAdmin(Usuario* u) {
        int op;

        do {
            cout << "\n�� MENU ADMIN ���\n";
            cout << "1. Ver usuarios\n";
            cout << "2. Buscar usuario\n";
            cout << "3. Entrar a mis finanzas\n";
            cout << "0. Salir\n";
            cin >> op;

            switch (op) {
                case 1: admin.listarUsuarios(); break;
                case 2: buscar(); break;
                case 3: u->menuFinanzas(); break;
            }

        } while (op != 0);
    }

    void menuEstudiante(Usuario* u) {
        int op;

        do {
            cout << "\n��� MENU ESTUDIANTE ���\n";
            cout << "1. Mis finanzas\n";
            cout << "0. Salir\n";
            cin >> op;

            if (op == 1)
                u->menuFinanzas();

        } while (op != 0);
    }

    void menuInvitado(Usuario* u) {
        cout << "\n��MENU INVITADO ��\n";
        cout << "Solo puede ver informaci�n\n";

        u->getFinanzas().mostrar();

        cout << "Acceso limitado\n";
    }

    void buscar() {
        int id;
        cout << "ID: ";
        cin >> id;

        Usuario* u = admin.buscarPorId(id);

        if (u != nullptr)
            u->getFinanzas().mostrar();
        else
            cout << "No encontrado\n";
    }
};
