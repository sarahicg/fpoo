/*
 Proposito:Esta clase "usuario" Representa a la persona o entidad dentro del sistema,permitiendole asi
 almacenar informacion personal a traves de un minimenu segun sea el requerimiento.

 Autores:  Michell Correa  - 2551211
           Sarahi Gomez    - 2551061-2724
            Christian Tapia - 2551312-2724
 Fecha : 05/05/2026
 Version:  1.0
 */
#pragma once
#include <string>
#include "Finanzas .h"
using namespace std;

class Usuario {
private:
    int id;
    string nombre;
    string password;
    string rol;

    Finanzas finanzas;

public:
    Usuario(int i, string n, string p, string r) {
        id = i;
        nombre = n;
        password = p;
        rol = r;
    }

    int getId() { return id; }
    string getNombre() { return nombre; }
    string getRol() { return rol; }

    bool login(string n, string p) {
        return (nombre == n && password == p);
    }

    Finanzas& getFinanzas() {
        return finanzas;
    }

    void menuFinanzas() {
        int op;

        do {
            cout << "\n1.Ingreso\n2.Gasto\n3.Ver estado\n0.Salir\n";
            cin >> op;

            switch (op) {
                case 1: finanzas.agregarIngreso(); break;
                case 2: finanzas.agregarGasto(); break;
                case 3: finanzas.mostrar(); break;
            }

        } while (op != 0);
    }

    float getIngresos() { return finanzas.getIngresos(); }
    float getGastos() { return finanzas.getGastos(); }
};
