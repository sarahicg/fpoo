#pragma once
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

class UsuarioNoRegistrado {
private:
    float vivienda = 0, alimentacion = 0, transporte = 0, estudios = 0, ocio = 0;
    float sinClasificar = 0, ingresosTotal = 0;
    float limiteMensual = 0;

    void filaEstado(string nombre, float valor) const {
        cout << "  " << left << setw(18) << nombre
             << "$ " << fixed << setprecision(2) << valor << endl;
    }

public:
    void agregarIngreso() {
        float ing;
        cout << "Ingrese ingresos: ";
        cin >> ing;
        if (ing > 0) ingresosTotal += ing;
    }

    void agregarGasto() {
        float gast;
        cout << "Ingrese gasto: ";
        cin >> gast;

        if (gast <= 0) return;

        int tipo;
        cout << "1.Vivienda 2.Alimentacion 3.Transporte 4.Estudios 5.Ocio\n";
        cin >> tipo;

        switch (tipo) {
            case 1: vivienda += gast; break;
            case 2: alimentacion += gast; break;
            case 3: transporte += gast; break;
            case 4: estudios += gast; break;
            case 5: ocio += gast; break;
            default: sinClasificar += gast;
        }
    }

    void mostrarEstado() const {
        float total = getTotalGastos();
        float balance = ingresosTotal - total;

        cout << "\nIngresos: " << ingresosTotal << endl;
        cout << "Gastos: " << total << endl;
        cout << "Balance: " << balance << endl;
    }

    float getTotalGastos() const {
        return vivienda + alimentacion + transporte + estudios + ocio + sinClasificar;
    }

    float getIngresos() const { return ingresosTotal; }
};
