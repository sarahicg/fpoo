/*
 Sistema de gesti�n de gastos para una persona natural que permite registrar datos personales e ingresos, as� como
  los cinco tipos de gastos mensuales (vivienda,alimentaci�n, transporte, servicios y otros), y obtener
  estad�sticas sobre dichos gastos.
 Autores:  Michell Correa  - 2551211
           Sarahi Gomez    - 2551061-2724
            Christian Tapia - 2551312-2724
 Fecha : 05/05/2026
 Version:  1.0
 */
#include "Sistema.h"

int main() {
    Sistema sistema;
    sistema.ejecutar();
    return 0;
}
